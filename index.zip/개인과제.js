
// api 키 복붙,

const rink = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4YzE2MzAwNzdmZThiYTNlZDliZWFkZGIxMGVmYTE5NyIsIm5iZiI6MTcyODk1NzExMy4wOTQ0ODMsInN1YiI6IjY3MGRjNTEyMGI4MDA1MzdkNzVjYjZiOCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.c_Fppe0Y7-k3S_--zjHYJYGlYUIHmxsUMX4U0QPd61I'
  }
};

// api 가져오기 및 카드박스 div 생성

// 스프레드로 풀어서 원소만 안에집어넣기, 풀어서 넣는건 (...)
const movies = []
// const movies2 = [response.results]
console.log(movies);


fetch('https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=ko-US&page=1&sort_by=popularity.desc', rink)
  .then((response) => response.json())
  .then((response) => {

    // fetch 안에있는 함수 밖으로 가져온거 //
    movies.push(...response.results);
    // fetch 안에있는 함수 밖으로 가져온거 //

    console.log(movies)

    for (let i = 0; i < response.results.length; i++) {
      const html = `
      <div class="movie-card" id=${response.results[i].id}>
        <img src="https://image.tmdb.org/t/p/w220_and_h330_face${response.results[i].poster_path}" alt="11" class="card-image">
        <div class="card-title">
          <h4>${response.results[i].title}</h4>
          <span class="card-star">평점:${Math.round(response.results[i].vote_average * 10) / 10}</span>
        </div>
      </div>
    `;
      document.querySelector(".card-container").innerHTML =
        document.querySelector(".card-container").innerHTML + html;
    }
  })
  .catch((err) => console.error(err));



// 인풋박스 
const modal1 = []
const input = document.querySelector("#searchInput")
// 인풋에 있는 밸류값 가져와야하는데 몰겠음 //
const form = document.querySelector(".form")
// 모달창

form.addEventListener('submit', function (event) {
  event.preventDefault()
  let isInclude = function (movies) {
    return movies.title.toLowerCase().includes(input.value.toLowerCase());
  }

  const filterMovies = movies.filter(isInclude);
  console.log(filterMovies)
  document.querySelector(".card-container").innerHTML = ""
  for (let i = 0; i < filterMovies.length; i++) {
    const resultHtml = `
  <div class="movie-card" id=${filterMovies[i].id}>
    <img src="https://image.tmdb.org/t/p/w220_and_h330_face${filterMovies[i].poster_path}" alt="11" class="card-image">
    <div class="card-title">
      <h4>${filterMovies[i].title}</h4>
      <span class="card-star">평점:${Math.round(filterMovies[i].vote_average * 10) / 10}</span>
    </div>
  </div>
`;

    document.querySelector(".card-container").innerHTML =
      document.querySelector(".card-container").innerHTML + resultHtml;

  }
})



// 인풋에있는 밸류값을 가져와서 타이틀에 포함되어있는지를 확인하고 포함이 되면 가져오기 true 없으면 flase
// includes 매서드 써야할듯?

// 여기에 이제 영화 사이트 타이틀을 가져와서 필터링 걸치게??



// form('이름',func){
// event.preventDefault()}


const modal = document.querySelector(".modalMain");
const openModal = document.querySelector(".card-container");
const cardMain = document.querySelector(".card-container")



openModal.addEventListener("click", (event) => {
  // 1. 카드 컨테이너를 방금 클릭한 영화카드 html을 가져오기
  // 2. 그 영화의 ID를 가져오기
  const cardEr = event.target.closest(".movie-card");

  // 1. 빈칸을 클릭했을때  즉시 함수를 종료
  if (!cardEr) {
    return;
  }
  // 
  const id = (event.target.closest(".movie-card").id);
  const selectedMovie = movies.find(
    (movie) => movie.id === Number(id)
  );
  console.log(selectedMovie)
  // 3. 2번에서 가져온 그 ID와 전체영화 목록중에서 같은ID를 가진 영화를 찾기
  const modalhtml = `
  <div class="modal-background">12</div>
    <div class="modalcontent">
        <img src="https://image.tmdb.org/t/p/w220_and_h330_face${selectedMovie.poster_path}" alt="11" class="card-image">
      <h1>제목:${selectedMovie.title}</h1>
      <p> 개봉일: ${selectedMovie.release_date}<p>
      <p>줄거리:${selectedMovie.overview}<p>
      <span class="modalclose">&times;</span>
      <span class="modalstar">평점:${Math.round(selectedMovie.vote_average * 10) / 10}</span>
    </div>
    `
  modal.innerHTML = modalhtml;
  modal.classList.remove("hide");
  const close = document.querySelector(".modalclose")
  const background = document.querySelector(".modal-background")

  close.addEventListener("click", () => {
    modal.classList.add('hide')
  })
  background.addEventListener("click", (event) => {
    if (event.target === background) {
      modal.classList.add('hide')
    }
  });
})


